# NodeJs CLI Starter template

Starter template to get going ith NodeJs CLI development.

Tooling configured

- [ ] ES6 support with babel
- [ ] Nodemon
- [ ] Test script with Jest
- [ ] build and watch-build scripts
- [ ] Prettier and Eslint configs

## Setup

Create a new repository using this template

- [ ] Being able to parameterise the setup
