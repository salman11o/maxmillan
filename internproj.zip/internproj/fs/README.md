# Security holding package

This package name is not currently in use, but was formerly occupied
by another package. To avoid malicious use, npm is hanging on to the
package name, but loosely, and we'll probably give it to you if you
want it.

You may adopt this package by contacting support@npmjs.com and
requesting the name.
